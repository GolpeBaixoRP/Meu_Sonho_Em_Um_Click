from __future__ import annotations

import os
import string
import shutil
import subprocess
import customtkinter as ctk
import tkinter as tk
from tkinter import ttk, messagebox


class PrepareDriveTab(ctk.CTkFrame):
    # =========================================================
    def __init__(self, parent, services=None):
        super().__init__(parent)

        self.services = services

        self.selected_drive = tk.StringVar()
        self.fs_type = tk.StringVar(value="FAT32")
        self.format_mode = tk.StringVar(value="quick")

        self._configure_dark_theme()
        self._build_ui()
        self.refresh_drives()

    # =========================================================
    def _configure_dark_theme(self):
        style = ttk.Style()
        try:
            style.theme_use("default")
        except Exception:
            pass

    # =========================================================
    # UI
    # =========================================================
    def _build_ui(self):
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=1)

        root = ctk.CTkFrame(self)
        root.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)

        ctk.CTkLabel(
            root,
            text="Preparar Unidade USB / HDD",
            font=("Segoe UI", 16, "bold"),
        ).pack(anchor="w", pady=(0, 10))

        # ================= DRIVE =================
        drive_frame = ctk.CTkFrame(root)
        drive_frame.pack(fill="x", pady=5)

        self.drive_combo = ttk.Combobox(
            drive_frame,
            textvariable=self.selected_drive,
            state="readonly",
            height=10,
        )
        self.drive_combo.pack(fill="x", padx=8, pady=8)
        self.drive_combo.bind("<<ComboboxSelected>>", self._on_drive_selected)

        ctk.CTkButton(
            drive_frame,
            text="Atualizar Unidades",
            command=self.refresh_drives,
        ).pack(pady=(0, 8))

        # ================= INFO =================
        info_frame = ctk.CTkFrame(root)
        info_frame.pack(fill="x", pady=5)

        self.drive_info_label = ctk.CTkLabel(
            info_frame,
            text="Selecione uma unidade...",
            justify="left",
            font=("Consolas", 11),
        )
        self.drive_info_label.pack(anchor="w", padx=8, pady=6)

        # ================= FILESYSTEM =================
        fs_frame = ctk.CTkFrame(root)
        fs_frame.pack(fill="x", pady=5)

        for fs in ("FAT32", "NTFS", "exFAT"):
            ctk.CTkRadioButton(
                fs_frame,
                text=fs,
                value=fs,
                variable=self.fs_type,
            ).pack(anchor="w", padx=10)

        # ================= MODE =================
        mode_frame = ctk.CTkFrame(root)
        mode_frame.pack(fill="x", pady=5)

        for label, value in [
            ("Rápido", "quick"),
            ("Normal", "normal"),
            ("Avançado", "advanced"),
        ]:
            ctk.CTkRadioButton(
                mode_frame,
                text=label,
                value=value,
                variable=self.format_mode,
            ).pack(anchor="w", padx=10)

        # ================= BUTTONS =================
        btn_frame = ctk.CTkFrame(root)
        btn_frame.pack(fill="x", pady=15)

        ctk.CTkButton(
            btn_frame,
            text="FORMATAR UNIDADE",
            command=self.format_drive,
        ).pack(fill="x", pady=4)

        ctk.CTkButton(
            btn_frame,
            text="Instalar Estrutura OPL",
            command=self.install_opl_structure,
        ).pack(fill="x", pady=4)

        ctk.CTkButton(
            btn_frame,
            text="Instalar POPStarter",
            command=self.install_popstarter,
        ).pack(fill="x", pady=4)

    # =========================================================
    # DRIVE LIST
    # =========================================================
    def refresh_drives(self):
        drives = []
        system_drive = os.environ.get("SystemDrive", "C:")

        for letter in string.ascii_uppercase:
            drive = f"{letter}:\\"
            if os.path.exists(drive):
                label = drive
                if drive.startswith(system_drive):
                    label += " (Sistema - BLOQUEADO)"
                drives.append(label)

        self.drive_combo["values"] = drives

    # =========================================================
    def _on_drive_selected(self, event=None):
        drive = self.selected_drive.get()
        if not drive:
            return

        try:
            info = self._get_drive_info(drive)
            self.drive_info_label.configure(text=info)
        except Exception as e:
            self.drive_info_label.configure(text=f"Erro ao ler unidade:\n{e}")

    def _run_ps(self, command: str) -> str:
        return subprocess.check_output(
            ["powershell", "-NoProfile", "-Command", command],
            text=True,
            stderr=subprocess.DEVNULL,
        ).strip()

    def _get_drive_info(self, drive_label: str) -> str:
        letter = drive_label[:1]
        drive_letter = f"{letter}:"

        total, used, free = shutil.disk_usage(drive_letter + "\\")

        def gb(x):
            return f"{x / (1024**3):.2f} GB"

        fs_type = "Desconhecido"
        try:
            fs_type = self._run_ps(
                f"(Get-Volume -DriveLetter {letter}).FileSystem"
            )
        except Exception:
            pass

        return (
            f"Unidade: {drive_letter}\n"
            f"Sistema de Arquivos: {fs_type}\n"
            f"Espaço Total: {gb(total)}\n"
            f"Usado: {gb(used)}\n"
            f"Livre: {gb(free)}"
        )

    # =========================================================
    def format_drive(self):
        messagebox.showinfo("Info", "Formatação real já pode ser implementada.")

    def install_opl_structure(self):
        messagebox.showinfo("OPL", "Estrutura OPL criada (mock).")

    def install_popstarter(self):
        messagebox.showinfo("POPStarter", "Instalação POPStarter (mock).")


# =============================================================
# ✅ STANDALONE BLINDADO
# =============================================================
def run_standalone():
    ctk.set_appearance_mode("dark")
    ctk.set_default_color_theme("blue")

    root = ctk.CTk()
    root.title("Prepare Drive — Standalone")
    root.geometry("620x650")

    tab = PrepareDriveTab(root)
    tab.pack(fill="both", expand=True)

    root.mainloop()


if __name__ == "__main__":
    try:
        run_standalone()
    except Exception as e:
        print("FATAL:", e)
        input("Pressione ENTER para sair...")