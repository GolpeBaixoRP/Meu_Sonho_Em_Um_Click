import os

def check_drive_integrity(drive_path):
    return os.path.exists(drive_path)
