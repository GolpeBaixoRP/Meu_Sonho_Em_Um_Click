from core.service_container import ServiceContainer


def build_services() -> ServiceContainer:
    return ServiceContainer()
