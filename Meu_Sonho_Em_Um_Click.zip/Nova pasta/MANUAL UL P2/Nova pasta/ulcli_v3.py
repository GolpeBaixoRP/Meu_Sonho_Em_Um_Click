import os
import sys
import struct
import shutil
import datetime
import hashlib
import zlib

SECTOR_SIZE = 2048
CHUNK_SIZE = 1073741824  # 1GB exato USBUtil
DVD_TYPE = 0x0014

LOG_FILE = None


# ==============================
# SISTEMA DE LOG
# ==============================
def init_log(game_name):
    global LOG_FILE
    os.makedirs("logs", exist_ok=True)
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    LOG_FILE = f"logs/{game_name}_{timestamp}.log"


def log(message):
    print(message)
    if LOG_FILE:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(message + "\n")


# ==============================
# CRC32 REAL IEEE
# ==============================
def calculate_crc32(path):
    log("[ETAPA 3] Calculando CRC32 real da ISO...")
    crc = 0
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            crc = zlib.crc32(chunk, crc)
    crc_final = f"{crc & 0xFFFFFFFF:08X}"
    log(f"CRC32: {crc_final}")
    return crc_final


# ==============================
# EXTRAÇÃO ISO9660 REAL
# ==============================
def extract_game_id(iso_path):
    log("[ETAPA 2] Extraindo GameID via ISO9660...")

    with open(iso_path, 'rb') as f:
        f.seek(16 * SECTOR_SIZE)
        pvd = f.read(SECTOR_SIZE)

        if pvd[1:6] != b'CD001':
            raise Exception("ISO9660 invalido")

        root_record = pvd[156:190]
        root_lba = int.from_bytes(root_record[2:6], 'little')
        root_size = int.from_bytes(root_record[10:14], 'little')

        f.seek(root_lba * SECTOR_SIZE)
        root_data = f.read(root_size)

        offset = 0
        while offset < len(root_data):
            length = root_data[offset]
            if length == 0:
                offset += 1
                continue

            record = root_data[offset:offset + length]
            file_lba = int.from_bytes(record[2:6], 'little')
            file_size = int.from_bytes(record[10:14], 'little')
            name_len = record[32]
            name = record[33:33 + name_len].decode(errors="ignore")

            if name.upper().startswith("SYSTEM.CNF"):
                f.seek(file_lba * SECTOR_SIZE)
                content = f.read(file_size).decode(errors="ignore")

                for line in content.splitlines():
                    if "BOOT2" in line.upper():
                        start = line.find("\\") + 1
                        end = line.find(";")
                        game_id = line[start:end]
                        log(f"GameID encontrado: {game_id}")
                        return game_id

            offset += length

    raise Exception("SYSTEM.CNF nao encontrado")


# ==============================
# FRAGMENTAÇÃO REAL USBUTIL
# ==============================
def split_iso(iso_path, dest, crc, game_id):
    log("[ETAPA 5] Iniciando fragmentacao USBUtil...")

    total_size = os.path.getsize(iso_path)
    log(f"Tamanho ISO: {total_size} bytes")

    part = 0
    offset = 0
    parts = []

    with open(iso_path, 'rb') as src:

        while offset < total_size:

            part_name = f"ul.{crc}.{game_id}.{part:02d}"
            part_path = os.path.join(dest, part_name)
            log(f"Criando parte: {part_name}")

            with open(part_path, 'wb') as dst:
                written = 0

                while written < CHUNK_SIZE and offset < total_size:
                    read_size = min(
                        4 * 1024 * 1024,
                        CHUNK_SIZE - written,
                        total_size - offset
                    )

                    buffer = src.read(read_size)
                    if not buffer:
                        break

                    dst.write(buffer)
                    written += len(buffer)
                    offset += len(buffer)

                log(f"Parte {part:02d} escrita: {written} bytes")

            parts.append(part_path)
            part += 1

    log(f"Total de partes criadas: {len(parts)}")
    return parts


# ==============================
# UL.CFG BINÁRIO REAL (64 bytes)
# ==============================
def create_ulcfg(dest, game_name, crc, part_count):

    log("[ETAPA 7] Criando UL.cfg binário real...")

    ulcfg_path = os.path.join(dest, "ul.cfg")

    name_bytes = game_name.encode("ascii", errors="ignore")[:32]
    name_bytes = name_bytes.ljust(32, b"\x00")

    base_name = crc.encode("ascii")[:12]
    base_name = base_name.ljust(12, b"\x00")

    parts_bytes = struct.pack("<H", part_count)
    type_bytes = struct.pack("<H", DVD_TYPE)
    flags_bytes = struct.pack("<I", 0)
    padding = b"\x00" * 12

    record = (
        name_bytes +
        base_name +
        parts_bytes +
        type_bytes +
        flags_bytes +
        padding
    )

    if len(record) != 64:
        raise Exception("Registro UL.cfg invalido")

    with open(ulcfg_path, "wb") as f:
        f.write(record)

    log("UL.cfg criado com 64 bytes exatos.")


# ==============================
# RECONSTRUÇÃO PARA TESTE
# ==============================
def rebuild_iso(parts, dest):
    log("[ETAPA 8] Reconstruindo ISO para teste...")

    rebuilt = os.path.join(dest, "rebuild_test.iso")

    with open(rebuilt, 'wb') as out:
        for p in parts:
            with open(p, 'rb') as part:
                shutil.copyfileobj(part, out)

    return rebuilt


# ==============================
# HASH SHA1 (TESTE)
# ==============================
def sha1_file(path):
    h = hashlib.sha1()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


# ==============================
# MAIN
# ==============================
def main():

    if len(sys.argv) < 3:
        print("Uso: python ulcli_v3.py caminho_iso pasta_destino")
        return

    iso_path = sys.argv[1]
    dest = sys.argv[2]

    if not os.path.exists(dest):
        os.makedirs(dest)

    game_name = os.path.splitext(os.path.basename(iso_path))[0]
    init_log(game_name)

    log("========== INICIO ==========")
    log(f"Arquivo recebido: {iso_path}")

    if not os.path.exists(iso_path):
        raise Exception("ISO nao encontrada")

    # ETAPA 2
    game_id = extract_game_id(iso_path)

    # ETAPA 3
    crc = calculate_crc32(iso_path)

    # ETAPA 5
    parts = split_iso(iso_path, dest, crc, game_id)

    # ETAPA 7
    create_ulcfg(dest, game_name, crc, len(parts))

    # ETAPA 8
    rebuilt = rebuild_iso(parts, dest)

    # ETAPA 9
    log("[ETAPA 9] Verificando integridade...")
    original_hash = sha1_file(iso_path)
    rebuilt_hash = sha1_file(rebuilt)

    log(f"SHA1 original: {original_hash}")
    log(f"SHA1 rebuild : {rebuilt_hash}")

    if original_hash == rebuilt_hash:
        log("INTEGRIDADE CONFIRMADA OK")
    else:
        log("ERRO: HASH DIFERENTE")

    log("========== FIM ==========")


if __name__ == "__main__":
    main()
