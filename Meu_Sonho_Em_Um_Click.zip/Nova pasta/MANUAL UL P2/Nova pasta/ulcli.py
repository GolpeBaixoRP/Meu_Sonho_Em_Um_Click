import os
import sys
import struct
import shutil
import datetime
import hashlib
import zlib

SECTOR_SIZE = 2048
CHUNK_SIZE = 1073741824  # 1GB
DVD_TYPE = 0x0014

LOG_FILE = None


# ==============================
# LOG
# ==============================
def init_log(game_name):
    global LOG_FILE
    os.makedirs("logs", exist_ok=True)
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    LOG_FILE = f"logs/{game_name}_{timestamp}.log"


def log(message):
    print(message)
    if LOG_FILE:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(message + "\n")


# ==============================
# CRC32 REAL
# ==============================
def calculate_crc32(path):
    log("[ETAPA 3] Calculando CRC32...")
    crc = 0
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            crc = zlib.crc32(chunk, crc)
    crc_final = f"{crc & 0xFFFFFFFF:08X}"
    log(f"CRC32: {crc_final}")
    return crc_final


# ==============================
# EXTRAÇÃO ISO9660
# ==============================
def extract_game_id(iso_path):
    log("[ETAPA 2] Extraindo GameID...")

    with open(iso_path, 'rb') as f:
        f.seek(16 * SECTOR_SIZE)
        pvd = f.read(SECTOR_SIZE)

        if pvd[1:6] != b'CD001':
            raise Exception("ISO9660 invalido")

        root_record = pvd[156:190]
        root_lba = int.from_bytes(root_record[2:6], 'little')
        root_size = int.from_bytes(root_record[10:14], 'little')

        f.seek(root_lba * SECTOR_SIZE)
        root_data = f.read(root_size)

        offset = 0
        while offset < len(root_data):
            length = root_data[offset]
            if length == 0:
                offset += 1
                continue

            record = root_data[offset:offset + length]
            file_lba = int.from_bytes(record[2:6], 'little')
            file_size = int.from_bytes(record[10:14], 'little')
            name_len = record[32]
            name = record[33:33 + name_len].decode(errors="ignore")

            if name.upper().startswith("SYSTEM.CNF"):
                f.seek(file_lba * SECTOR_SIZE)
                content = f.read(file_size).decode(errors="ignore")

                for line in content.splitlines():
                    if "BOOT2" in line.upper():
                        start = line.find("\\") + 1
                        end = line.find(";")
                        game_id = line[start:end]
                        log(f"GameID: {game_id}")
                        return game_id

            offset += length

    raise Exception("SYSTEM.CNF nao encontrado")


# ==============================
# FRAGMENTAÇÃO
# ==============================
def split_iso(iso_path, dest, crc, game_id):
    log("[ETAPA 5] Fragmentando ISO...")

    total_size = os.path.getsize(iso_path)
    part = 0
    offset = 0
    parts = []

    with open(iso_path, 'rb') as src:

        while offset < total_size:

            part_name = f"ul.{crc}.{game_id}.{part:02d}"
            part_path = os.path.join(dest, part_name)
            log(f"Criando: {part_name}")

            with open(part_path, 'wb') as dst:
                written = 0

                while written < CHUNK_SIZE and offset < total_size:
                    read_size = min(
                        4 * 1024 * 1024,
                        CHUNK_SIZE - written,
                        total_size - offset
                    )

                    buffer = src.read(read_size)
                    if not buffer:
                        break

                    dst.write(buffer)
                    written += len(buffer)
                    offset += len(buffer)

            parts.append(part_path)
            part += 1

    log(f"Total partes: {len(parts)}")
    return parts


# ==============================
# UL.CFG REAL (ul.GAMEID)
# ==============================
def create_ulcfg(dest, game_name, game_id, part_count):

    log("[ETAPA 7] Atualizando UL.cfg...")

    ulcfg_path = os.path.join(dest, "ul.cfg")

    name_bytes = game_name.encode("ascii", errors="ignore")[:32]
    name_bytes = name_bytes.ljust(32, b"\x00")

    base_string = f"ul.{game_id}"
    base_bytes = base_string.encode("ascii")
    base_bytes = base_bytes.ljust(16, b"\x00")  # agora 16 bytes

    parts_bytes = struct.pack("<H", part_count)
    type_bytes = struct.pack("<H", DVD_TYPE)
    flags_bytes = struct.pack("<I", 0)
    padding = b"\x00" * (64 - (32 + 16 + 2 + 2 + 4))

    record = (
        name_bytes +
        base_bytes +
        parts_bytes +
        type_bytes +
        flags_bytes +
        padding
    )

    if len(record) != 64:
        raise Exception("Registro UL.cfg invalido")

    # AGORA EM MODO APPEND
    with open(ulcfg_path, "ab") as f:
        f.write(record)

    log("Registro adicionado ao UL.cfg")


# ==============================
# MAIN
# ==============================
def main():

    if len(sys.argv) < 3:
        print("Uso: python ulcli_v4.py caminho_iso pasta_destino")
        return

    iso_path = sys.argv[1]
    dest = sys.argv[2]

    if not os.path.exists(dest):
        os.makedirs(dest)

    game_name = os.path.splitext(os.path.basename(iso_path))[0]
    init_log(game_name)

    log("========== INICIO ==========")

    game_id = extract_game_id(iso_path)
    crc = calculate_crc32(iso_path)
    parts = split_iso(iso_path, dest, crc, game_id)

    create_ulcfg(dest, game_name, game_id, len(parts))

    log("========== FIM ==========")


if __name__ == "__main__":
    main()
