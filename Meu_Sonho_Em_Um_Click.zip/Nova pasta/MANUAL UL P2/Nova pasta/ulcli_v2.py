import os
import sys
import math
import hashlib
import shutil
import datetime

SECTOR_SIZE = 2048
MAX_CHUNK = 4294967040  # Limite seguro FAT32

LOG_FILE = None


# ==============================
# SISTEMA DE LOG
# ==============================
def init_log(game_name):
    global LOG_FILE
    os.makedirs("logs", exist_ok=True)
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    LOG_FILE = f"logs/{game_name}_{timestamp}.log"


def log(message):
    print(message)
    if LOG_FILE:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(message + "\n")


# ==============================
# HASH
# ==============================
def sha1_file(path):
    h = hashlib.sha1()
    with open(path, 'rb') as f:
        while True:
            chunk = f.read(1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


# ==============================
# EXTRAÇÃO REAL ISO9660
# ==============================
def extract_game_id(iso_path):
    log("[ETAPA 2] Extraindo GameID via ISO9660 real...")

    with open(iso_path, 'rb') as f:

        # Ler Primary Volume Descriptor (Setor 16)
        f.seek(16 * SECTOR_SIZE)
        pvd = f.read(SECTOR_SIZE)

        if pvd[1:6] != b'CD001':
            raise Exception("ISO9660 invalido")

        # Root directory record começa no offset 156
        root_record = pvd[156:190]

        root_lba = int.from_bytes(root_record[2:6], 'little')
        root_size = int.from_bytes(root_record[10:14], 'little')

        log(f"Root LBA: {root_lba}")
        log(f"Root Size: {root_size}")

        # Ir para root
        f.seek(root_lba * SECTOR_SIZE)
        root_data = f.read(root_size)

        offset = 0
        while offset < len(root_data):

            length = root_data[offset]
            if length == 0:
                offset += 1
                continue

            record = root_data[offset:offset + length]

            file_lba = int.from_bytes(record[2:6], 'little')
            file_size = int.from_bytes(record[10:14], 'little')
            name_len = record[32]
            name = record[33:33 + name_len].decode(errors="ignore")

            if name.upper().startswith("SYSTEM.CNF"):
                log("SYSTEM.CNF encontrado")

                f.seek(file_lba * SECTOR_SIZE)
                content = f.read(file_size).decode(errors="ignore")

                for line in content.splitlines():
                    if "BOOT2" in line.upper():
                        start = line.find("\\") + 1
                        end = line.find(";")
                        game_id = line[start:end]
                        log(f"GameID encontrado: {game_id}")
                        return game_id

            offset += length

    raise Exception("SYSTEM.CNF nao encontrado")


# ==============================
# DIVISAO DA ISO
# ==============================
def split_iso(iso_path, dest, game_id):
    log("[ETAPA 5] Iniciando fragmentacao...")

    total_size = os.path.getsize(iso_path)
    log(f"Tamanho ISO: {total_size} bytes")

    part = 0
    offset = 0
    parts = []

    with open(iso_path, 'rb') as src:

        while offset < total_size:

            part_name = f"ul.{game_id}.{part:02d}"
            part_path = os.path.join(dest, part_name)
            log(f"Criando parte: {part_name}")

            with open(part_path, 'wb') as dst:
                written = 0

                while written < MAX_CHUNK and offset < total_size:
                    read_size = min(
                        4 * 1024 * 1024,
                        MAX_CHUNK - written,
                        total_size - offset
                    )

                    buffer = src.read(read_size)
                    if not buffer:
                        break

                    dst.write(buffer)
                    written += len(buffer)
                    offset += len(buffer)

                log(f"Parte {part:02d} escrita: {written} bytes")

            parts.append(part_path)
            part += 1

    log(f"Total de partes criadas: {len(parts)}")
    return parts


# ==============================
# RECONSTRUCAO
# ==============================
def rebuild_iso(parts, dest):
    log("[ETAPA 8] Reconstruindo ISO para teste...")

    rebuilt = os.path.join(dest, "rebuild_test.iso")

    with open(rebuilt, 'wb') as out:
        for p in parts:
            with open(p, 'rb') as part:
                shutil.copyfileobj(part, out)

    return rebuilt


# ==============================
# UL.CFG (Debug Simples)
# ==============================
def create_ulcfg(dest, game_id, total_size, part_count):
    log("[ETAPA 7] Criando UL.cfg...")

    ulcfg_path = os.path.join(dest, "UL.cfg")

    with open(ulcfg_path, 'a', encoding="utf-8") as f:
        f.write(f"{game_id}|{total_size}|{part_count}\n")

    log("UL.cfg atualizado.")


# ==============================
# MAIN
# ==============================
def main():

    if len(sys.argv) < 3:
        print("Uso: python ulcli_v2.py caminho_iso pasta_destino")
        return

    iso_path = sys.argv[1]
    dest = sys.argv[2]

    if not os.path.exists(dest):
        os.makedirs(dest)

    game_name = os.path.splitext(os.path.basename(iso_path))[0]
    init_log(game_name)

    log("========== INICIO ==========")
    log(f"Arquivo recebido: {iso_path}")

    # ETAPA 1
    log("[ETAPA 1] Validando ISO...")
    if not os.path.exists(iso_path):
        raise Exception("ISO nao encontrada")

    total_size = os.path.getsize(iso_path)
    log(f"Tamanho total: {total_size}")

    # ETAPA 2
    game_id = extract_game_id(iso_path)

    # ETAPA 5
    parts = split_iso(iso_path, dest, game_id)

    # ETAPA 7
    create_ulcfg(dest, game_id, total_size, len(parts))

    # ETAPA 8
    rebuilt = rebuild_iso(parts, dest)

    # ETAPA 9
    log("[ETAPA 9] Verificando integridade...")
    original_hash = sha1_file(iso_path)
    rebuilt_hash = sha1_file(rebuilt)

    log(f"SHA1 original: {original_hash}")
    log(f"SHA1 rebuild : {rebuilt_hash}")

    if original_hash == rebuilt_hash:
        log("INTEGRIDADE CONFIRMADA OK")
    else:
        log("ERRO: HASH DIFERENTE")

    log("========== FIM ==========")


if __name__ == "__main__":
    main()
