import os
import sys
import hashlib
import json
import datetime
import platform
from pathlib import Path

BLOCK_SIZE = 16 * 1024 * 1024  # 16MB blocos grandes
READ_BUFFER = 65536

def sha_hash(path, algo="sha1"):
    h = hashlib.new(algo)
    with open(path, "rb") as f:
        while chunk := f.read(READ_BUFFER):
            h.update(chunk)
    return h.hexdigest()

def block_hashes(path):
    hashes = []
    with open(path, "rb") as f:
        index = 0
        while True:
            data = f.read(BLOCK_SIZE)
            if not data:
                break
            h = hashlib.sha1(data).hexdigest()
            hashes.append({
                "block_index": index,
                "sha1": h
            })
            index += 1
    return hashes

def merkle_summary(block_hash_list):
    concat = "".join(b["sha1"] for b in block_hash_list).encode()
    return hashlib.sha1(concat).hexdigest()

def main(target_dir):
    timestamp = datetime.datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    report = {
        "capture_time_utc": timestamp,
        "system": platform.platform(),
        "block_size": BLOCK_SIZE,
        "files": {}
    }

    for file in sorted(Path(target_dir).glob("*")):
        if not file.is_file():
            continue

        size = os.path.getsize(file)

        print(f"[+] Processando {file.name}")

        blocks = block_hashes(file)

        report["files"][file.name] = {
            "size": size,
            "multiple_2048": size % 2048 == 0,
            "sha1": sha_hash(file, "sha1"),
            "sha256": sha_hash(file, "sha256"),
            "block_hashes": blocks,
            "merkle_root": merkle_summary(blocks)
        }

    with open("forensic_compact_report.json", "w") as f:
        json.dump(report, f, indent=4)

    print("\nRelatório compacto gerado: forensic_compact_report.json\n")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Uso: python forensic_ul_capture_compact.py <diretorio_UL>")
        sys.exit(1)

    main(sys.argv[1])
