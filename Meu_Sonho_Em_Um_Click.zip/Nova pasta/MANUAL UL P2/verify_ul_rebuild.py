import os
import hashlib
import json
from pathlib import Path

# ==========================
# CONFIGURAÇÃO
# ==========================
UL_FOLDER = r"D:\POPS"   # <- SUA PASTA UL
OUTPUT_FOLDER = "reconstruidos"
REPORT_FILE = "relatorio_verificacao.json"
# ==========================


def sha1_file(path):
    h = hashlib.sha1()
    with open(path, 'rb') as f:
        while chunk := f.read(1024 * 1024):
            h.update(chunk)
    return h.hexdigest()


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        while chunk := f.read(1024 * 1024):
            h.update(chunk)
    return h.hexdigest()


def get_ul_games(folder):
    jogos = {}

    for file in os.listdir(folder):
        if file.startswith("ul."):
            partes = file.split(".")
            if len(partes) >= 5:
                base = ".".join(partes[:-1])  # tudo menos índice final
                jogos.setdefault(base, []).append(file)

    # Ordenar corretamente cada jogo pelo índice final
    for base in jogos:
        jogos[base].sort(key=lambda x: int(x.split('.')[-1]))

    return jogos


def rebuild_iso(folder, output_file, parts):
    with open(output_file, "wb") as outfile:
        for part in parts:
            part_path = os.path.join(folder, part)
            with open(part_path, "rb") as infile:
                while chunk := infile.read(1024 * 1024):
                    outfile.write(chunk)


def main():
    folder = Path(UL_FOLDER)

    if not folder.exists():
        print("Pasta UL não encontrada.")
        return

    os.makedirs(OUTPUT_FOLDER, exist_ok=True)

    jogos = get_ul_games(folder)

    if not jogos:
        print("Nenhum jogo UL encontrado.")
        return

    relatorio_final = {}

    for nome_jogo, parts in jogos.items():

        print("\n======================================")
        print(f"Reconstruindo jogo: {nome_jogo}")
        print(f"Quantidade de partes: {len(parts)}")

        output_iso = os.path.join(OUTPUT_FOLDER, f"{nome_jogo}.iso")

        rebuild_iso(folder, output_iso, parts)

        print("Calculando hashes...")

        rebuilt_sha1 = sha1_file(output_iso)
        rebuilt_sha256 = sha256_file(output_iso)
        rebuilt_size = os.path.getsize(output_iso)

        print("Tamanho:", rebuilt_size)
        print("SHA1:", rebuilt_sha1)
        print("SHA256:", rebuilt_sha256)

        relatorio_final[nome_jogo] = {
            "partes": parts,
            "quantidade_partes": len(parts),
            "tamanho_reconstruido": rebuilt_size,
            "sha1_reconstruido": rebuilt_sha1,
            "sha256_reconstruido": rebuilt_sha256
        }

    with open(REPORT_FILE, "w", encoding="utf-8") as f:
        json.dump(relatorio_final, f, indent=4)

    print("\n======================================")
    print("Processo finalizado.")
    print("ISOs reconstruídas na pasta:", OUTPUT_FOLDER)
    print("Relatório salvo em:", REPORT_FILE)


if __name__ == "__main__":
    main()
