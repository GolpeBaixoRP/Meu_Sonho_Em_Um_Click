import os
import hashlib
import json

# ==========================
# CONFIGURAÇÃO MANUAL
# ==========================
ISO_ORIGINAL = r"D:\POPS\isos\Midnight Club 3 - DUB Edition Remix.iso"
ISO_RECONSTRUIDA = r"D:\POPS\reconstruidos\ul.A800424A.SLUS_213.55.iso"
RELATORIO = "relatorio_comparacao_mgs2.json"
# ==========================


def sha1_file(path):
    h = hashlib.sha1()
    with open(path, 'rb') as f:
        while chunk := f.read(1024 * 1024):
            h.update(chunk)
    return h.hexdigest()


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        while chunk := f.read(1024 * 1024):
            h.update(chunk)
    return h.hexdigest()


def compare_byte_by_byte(file1, file2):
    with open(file1, 'rb') as f1, open(file2, 'rb') as f2:
        offset = 0
        chunk_size = 1024 * 1024

        while True:
            b1 = f1.read(chunk_size)
            b2 = f2.read(chunk_size)

            if not b1 and not b2:
                return True, None

            if b1 != b2:
                for i in range(min(len(b1), len(b2))):
                    if b1[i] != b2[i]:
                        return False, offset + i
                return False, offset

            offset += chunk_size


def main():

    if not os.path.exists(ISO_ORIGINAL):
        print("ISO original não encontrada.")
        return

    if not os.path.exists(ISO_RECONSTRUIDA):
        print("ISO reconstruída não encontrada.")
        return

    print("Calculando hashes...\n")

    original_sha1 = sha1_file(ISO_ORIGINAL)
    original_sha256 = sha256_file(ISO_ORIGINAL)
    original_size = os.path.getsize(ISO_ORIGINAL)

    rebuilt_sha1 = sha1_file(ISO_RECONSTRUIDA)
    rebuilt_sha256 = sha256_file(ISO_RECONSTRUIDA)
    rebuilt_size = os.path.getsize(ISO_RECONSTRUIDA)

    print("Comparando byte a byte...")
    identical, diff_offset = compare_byte_by_byte(
        ISO_ORIGINAL,
        ISO_RECONSTRUIDA
    )

    resultado = {
        "original": {
            "tamanho": original_size,
            "sha1": original_sha1,
            "sha256": original_sha256
        },
        "reconstruida": {
            "tamanho": rebuilt_size,
            "sha1": rebuilt_sha1,
            "sha256": rebuilt_sha256
        },
        "sha1_confere": original_sha1 == rebuilt_sha1,
        "sha256_confere": original_sha256 == rebuilt_sha256,
        "byte_a_byte_identico": identical,
        "primeira_diferenca_offset": diff_offset
    }

    with open(RELATORIO, "w", encoding="utf-8") as f:
        json.dump(resultado, f, indent=4)

    print("\n===== RESULTADO =====")
    print("SHA1 confere? ", resultado["sha1_confere"])
    print("SHA256 confere? ", resultado["sha256_confere"])
    print("Byte a byte idêntico? ", resultado["byte_a_byte_identico"])

    if not identical:
        print("Primeira diferença no byte:", diff_offset)

    print("\nRelatório salvo em:", RELATORIO)


if __name__ == "__main__":
    main()
