import os
import zlib

# ==============================
# CRC32 IDÊNTICO AO USBUTIL
# ==============================
def calculate_crc32(filepath):
    crc = 0xFFFFFFFF
    with open(filepath, "rb") as f:
        while True:
            chunk = f.read(1024 * 1024)
            if not chunk:
                break
            crc = zlib.crc32(chunk, crc)
    crc ^= 0xFFFFFFFF
    return crc & 0xFFFFFFFF


# ==============================
# DIVIDIR ISO EM PARTES 1GB
# ==============================
def split_iso(iso_path, output_dir, game_id):
    crc = calculate_crc32(iso_path)
    crc_hex = f"{crc:08X}"

    part_size = 1024 * 1024 * 1024  # 1GB
    part_number = 0
    parts_created = 0

    with open(iso_path, "rb") as iso:
        while True:
            chunk = iso.read(part_size)
            if not chunk:
                break

            filename = f"ul.{crc_hex}.{game_id}.{part_number:02d}"
            filepath = os.path.join(output_dir, filename)

            with open(filepath, "wb") as part_file:
                part_file.write(chunk)

            part_number += 1
            parts_created += 1

    return crc, crc_hex, parts_created


# ==============================
# ESCREVER UL.CFG (64 BYTES)
# ==============================
def write_ul_cfg(cfg_path, game_name, game_id, crc, media_type, parts):
    record = bytearray(64)

    # 1️⃣ Nome do jogo — 32 bytes — padded com ESPAÇO (0x20)
    name_bytes = game_name.encode("ascii", errors="ignore")[:32]
    record[0:len(name_bytes)] = name_bytes

    for i in range(len(name_bytes), 32):
        record[i] = 0x20  # padding com espaço

    # 2️⃣ Campo ID — 15 bytes — "ul.SLUS_205.54"
    id_string = f"ul.{game_id}"
    id_bytes = id_string.encode("ascii")[:15]
    record[32:32+len(id_bytes)] = id_bytes

    # 3️⃣ Byte 0x00 após ID
    record[47] = 0x00

    # 4️⃣ CRC little-endian
    record[48:52] = crc.to_bytes(4, byteorder="little")

    # 5️⃣ Tipo de mídia
    # DVD = 0x12
    # CD  = 0x14
    record[52] = 0x12 if media_type.upper() == "DVD" else 0x14

    # 6️⃣ Número de partes
    record[53] = parts

    # 7️⃣ Restante já é 0x00

    with open(cfg_path, "ab") as f:
        f.write(record)


# ==============================
# FUNÇÃO PRINCIPAL
# ==============================
def process_game(iso_path, output_dir, game_name, game_id, media_type="DVD"):

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    print("Calculando CRC...")
    crc, crc_hex, parts = split_iso(iso_path, output_dir, game_id)

    print("CRC encontrado:", crc_hex)
    print("Partes criadas:", parts)

    cfg_path = os.path.join(output_dir, "ul.cfg")

    write_ul_cfg(cfg_path, game_name, game_id, crc, media_type, parts)

    print("ul.cfg atualizado com sucesso.")
    print("Processo finalizado.")


# ==============================
# EXEMPLO DE USO
# ==============================
if __name__ == "__main__":

    iso_path = "Metal Gear Solid 2 - Substance.iso"
    output_dir = "output"
    game_name = "Metal Gear Solid 2 - Substance"
    game_id = "SLUS_205.54"
    media_type = "DVD"

    process_game(iso_path, output_dir, game_name, game_id, media_type)
