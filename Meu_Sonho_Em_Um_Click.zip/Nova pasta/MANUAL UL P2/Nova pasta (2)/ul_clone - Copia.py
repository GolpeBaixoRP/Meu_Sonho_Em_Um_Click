import os
import re
import zlib
import logging
from pathlib import Path
from datetime import datetime

# ==============================
# CONFIGURAÇÃO FIXA DE PASTAS
# ==============================

BASE_DIR = Path(__file__).parent
INPUT_DIR = BASE_DIR / "input"
OUTPUT_DIR = BASE_DIR / "output"
LOG_DIR = BASE_DIR / "logs"

CHUNK_SIZE = 1024 * 1024 * 1024  # 1GB padrão UL

# Criar pastas se não existirem
INPUT_DIR.mkdir(exist_ok=True)
OUTPUT_DIR.mkdir(exist_ok=True)
LOG_DIR.mkdir(exist_ok=True)

# ==============================
# CONFIGURAÇÃO DE LOG
# ==============================

log_file = LOG_DIR / f"log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"

logging.basicConfig(
    filename=log_file,
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

logging.info("==== INÍCIO DO PROCESSAMENTO UL ====")


# ==============================
# FUNÇÕES
# ==============================

def extract_game_id(iso_path):
    logging.info(f"Extraindo Game ID de {iso_path.name}")
    with open(iso_path, 'rb') as f:
        data = f.read()

    match = re.search(rb'(SLUS|SLES|SCES|SCUS|SLPM|SLPS)[-_]\d{3}\.\d{2}', data)
    if match:
        game_id = match.group().decode().replace('-', '_')
        logging.info(f"Game ID encontrado: {game_id}")
        return game_id
    else:
        logging.warning("Game ID não encontrado.")
        return "UNKNOWN_000.00"


def calculate_crc(game_name):
    crc = format(zlib.crc32(game_name.encode()) & 0xFFFFFFFF, '08X')
    logging.info(f"CRC calculado: {crc}")
    return crc


def detect_media_type(iso_path):
    size = os.path.getsize(iso_path)
    logging.info(f"Tamanho da ISO: {size} bytes")

    if size > 800 * 1024 * 1024:
        logging.info("Detectado como DVD (regra tamanho).")
        return "DVD"

    with open(iso_path, 'rb') as f:
        f.seek(0x8000)
        descriptor = f.read(2048)
        if b'CD001' in descriptor:
            logging.info("Detectado como CD (volume descriptor).")
            return "CD"

    logging.info("Fallback: DVD")
    return "DVD"


def append_ul_cfg(game_name, game_id, crc, media_type):
    cfg_path = OUTPUT_DIR / "ul.cfg"
    entry = f"{game_name}|{game_id}|ul.{crc}.{game_id}|{media_type}\n"

    if cfg_path.exists():
        with open(cfg_path, "r", encoding="utf-8") as cfg:
            if entry in cfg.read():
                logging.info("Entrada já existente no ul.cfg")
                return

    with open(cfg_path, "a", encoding="utf-8") as cfg:
        cfg.write(entry)

    logging.info("ul.cfg atualizado.")


def split_iso_ul(iso_path):
    logging.info(f"Iniciando divisão UL para {iso_path.name}")

    game_name = iso_path.stem
    game_id = extract_game_id(iso_path)
    crc = calculate_crc(game_name)
    media_type = detect_media_type(iso_path)

    part_number = 0

    with open(iso_path, 'rb') as f:
        while True:
            chunk = f.read(CHUNK_SIZE)
            if not chunk:
                break

            filename = f"ul.{crc}.{game_id}.{part_number:02d}"
            output_file = OUTPUT_DIR / filename

            with open(output_file, 'wb') as out:
                out.write(chunk)

            logging.info(f"Criado arquivo: {filename}")
            part_number += 1

    append_ul_cfg(game_name, game_id, crc, media_type)

    logging.info(f"Finalizado UL para {iso_path.name}")


# ==============================
# PROCESSAMENTO AUTOMÁTICO
# ==============================

def main():
    logging.info("Procurando ISOs na pasta input.")

    isos = list(INPUT_DIR.glob("*.iso"))

    if not isos:
        logging.warning("Nenhuma ISO encontrada na pasta input.")
        print("Nenhuma ISO encontrada na pasta input.")
        return

    for iso in isos:
        try:
            split_iso_ul(iso)
            print(f"Processado: {iso.name}")
        except Exception as e:
            logging.error(f"Erro ao processar {iso.name}: {str(e)}")
            print(f"Erro ao processar {iso.name}")

    logging.info("==== PROCESSAMENTO FINALIZADO ====")
    print("\nProcessamento concluído.")
    print(f"Log salvo em: {log_file}")


if __name__ == "__main__":
    main()
